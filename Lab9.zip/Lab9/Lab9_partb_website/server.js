// Load the modules
var express = require('express'); //Express - a web application framework that provides useful utility functions like 'http'
var app = express();
var bodyParser = require('body-parser'); // Body-parser -- a library that provides functions for parsing incoming requests
const { response } = require('express');
app.use(bodyParser.json());              // Support json encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // Support encoded bodies


// Set the view engine to ejs
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/'));// Set the relative path; makes accessing the resource directory easier

// Simple get api provided to check if the node.js starts up successfully. Opening up http://localhost:3000 should display the below returned json.
app.get("/", (req, res) => {
  res.json({ status: "success", message: "Welcome!" });
});

//Add your code support two new API's /add and /divide here.

app.post("/add", (req, res) => {
  if(typeof(req.body.n1) !== 'number'){
    return res.status(404).send("Invalid insert");
  }  
  if(typeof (req.body.n2) !== 'number'){
    return res.status(404).send("Invalid insert");
  }
  const num1 = req.body.n1;
  const num2 = req.body.n2;
  const sum = num1 + num2;
  res.status(200).send({result: sum});
});

app.post("/divide",(req, res)=>{
  if (typeof (req.body.n1) !== 'number' || typeof (req.body.n2) !== 'number' )
    return res.status(404).send("Invalid insert");

  if(req.body.n2 == 0)
    return res.status(404).send("undefined");
  
  
  const num1 = req.body.n1;
  const num2 = req.body.n2;
  const div = num1/num2;
  res.status(200).send({ result: div});
});


module.exports = app.listen(3000);
console.log('3000 is the magic port');
