// Imports the server.js file to be tested.
let server = require("../server");
//Assertion (Test Driven Development) and Should, Expect(Behaviour driven development) library
let chai = require("chai");
// Chai HTTP provides an interface for live integration testing of the API's.
let chaiHttp = require("chai-http");
chai.should();
chai.use(chaiHttp); 
const { expect } = chai;
var assert = chai.assert;


//Import complete


describe("Server!", () => {
      // Add your test cases here
      it("Returns the default welcome message", done => {
            let num = {
                  num1: 1,
                  num2: 1
            }
            chai
            .request(server)
            .post("/add")
            .send(num)
            .end((err, res) => {
                  res.body.should.have.property("result").eq(2);
                  done();
            });
      });
      it("Returns the default welcome message", done => {
            let num = {
                  num1: 't',
                  num2: 1
            }
            chai
            .request(server)
            .post("/add")
            .send(num)
            .end((err, res) => {
                  expect(res).to.have.status(404);
                  done();
            });
      });
      it("Returns the default welcome message", done => {
            let num = {
                  num1: 15,
                  num2: 3
            }
            chai
                  .request(server)
                  .post("/divide")
                  .send(num)
                  .end((err, res) => {
                        res.body.should.have.property("result").eq(5);
                        done();
                  });
      });
      it("Returns the default welcome message", done => {
            let num = {
                  num1: 10,
                  num2: 0
            }
            chai
            .request(server)
            .post("/divide")
            .send(num)
            .end((err, res) => {
                  expect(res).to.have.status(404);
                  done();
            });
      });

});