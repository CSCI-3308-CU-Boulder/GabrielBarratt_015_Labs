// Gabriel Barratt & Tien Duong
function APICall()
{
    $(document).ready(function() 
    {
        var tester = document.getElementById("searchTag").value;
        console.log(tester);

        var size = document.getElementById("size");
        var answer = size.options[size.selectedIndex].value;

        var url = 'https://www.flickr.com/services/rest/?method=flickr.photos.search&api_key=fe2c141292c3672eeee0840c9837ec5a&tags=' + tester + '&privacy_filter=1&safe_search=1&extras=url_sq&page=' + answer + '&format=json&nojsoncallback=1'; //Place your Flickr API Call Here
        $.ajax({url:url, dataType:"json"}).then(function(data) 
        {
          console.log(data);
          
          console.log("https://live.staticflickr.com/" + data.photos.photo[0].server + "/" + data.photos.photo[0].id + "_" + data.photos.photo[0].secret + ".jpg");

          for(var i = 0; i < answer; i++){
            var card = document.createElement("div");
            card.setAttribute("width", "8rem;");
            card.className = "card";

            var cardbody = document.createElement("div");
            cardbody.className = "card-body";

            var cardtitle = document.createTextNode(data.photos.photo[i].title);
            cardtitle.className = 'card-title';

            var cardimg = document.createElement("img");
            cardimg.className = 'card-img-top';
            cardimg.setAttribute("src", "https://live.staticflickr.com/" + data.photos.photo[i].server + "/" + data.photos.photo[i].id + "_" + data.photos.photo[i].secret + ".jpg");
            cardimg.setAttribute("width", "15");
            cardimg.setAttribute("height", "200");

            card.appendChild(cardimg);
            cardbody.appendChild(cardtitle);
            card.appendChild(cardbody);

            document.getElementById("cardStorage").appendChild(card);
          }
        })
      })
}